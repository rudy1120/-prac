package egovframework.hyb.mbl.jai.service;

import egovframework.com.cmm.vo.DefaultSearchVO;

/**  
 * @Class Name : JailbreakDetectionDeviceAPIDefaultVO
 * @Description : JailbreakDetectionDeviceAPIDefaultVO Class
 * @Modification Information  
 * @
 * @  수정일       수정자                  수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2016.07.26    신성학                최초 작성
 * 
 * @author 디바이스 API 실행환경 개발팀
 * @since 2016. 07. 26
 * @version 1.0
 * @see
 * 
 *  Copyright (C) by Ministry of Interior All right reserved.
 */

public class JailbreakDetectionDeviceAPIDefaultVO extends DefaultSearchVO {
	
	private static final long serialVersionUID = 1607939443103082103L;

}
