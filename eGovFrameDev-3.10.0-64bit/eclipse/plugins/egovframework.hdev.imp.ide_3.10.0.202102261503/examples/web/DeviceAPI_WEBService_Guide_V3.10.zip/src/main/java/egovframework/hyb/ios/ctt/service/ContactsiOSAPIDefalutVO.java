package egovframework.hyb.ios.ctt.service;

import egovframework.com.cmm.vo.DefaultSearchVO;

/**  
 * @Class Name : ContactsAndroidAPIDefalutVO.java
 * @Description : ContactsAndroidAPIDefalutVO Class
 * @Modification Information  
 * @
 * @ 수정일                수정자             수정내용
 * @ ----------   ---------   -------------------------------
 *   2012.08.13   나신일              최초생성
 *   2012.08.23   이해성              커스터마이징
 *   2020.08.14   신용호              Swagger 적용
 * 
 * @author Device API 실행환경팀
 * @since 2012. 08. 13
 * @version 1.0
 * @see
 * 
 */
public class ContactsiOSAPIDefalutVO extends DefaultSearchVO {

	private static final long serialVersionUID = 5791756433802625423L;

}
