package egovframework.com.cop.cmy.service;

import java.util.List;

import egovframework.com.cop.bbs.service.BoardMasterVO;

public interface EgovCommuBBSMasterService {

	List<BoardMasterVO> selectCommuBBSMasterListMain(BoardMasterVO bbsVo);

}
